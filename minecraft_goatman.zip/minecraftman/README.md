# The Horrors in the Fog
**注意**: 此版本基于 theernyclan 的 "The Horrors in the Fog" 进行了修改。。

修改日期: [2025/10/17]
修改者: [""]

## 许可证

本项目基于 GNU General Public License v3.0 (GPLv3) 发布。

### 你的权利
根据 GPLv3，你有权：
- 自由运行此程序
- 学习和修改源代码
- 重新分发原版程序
- 分发你修改后的版本

### 你的义务
如果你分发此程序（无论是原版还是修改版），你必须：
- 提供完整的 GPLv3 许可证文本
- 提供相应的源代码
- 保持相同的许可证条款
- 明确标注所做的修改

## 源代码
本项目的完整源代码可在以下位置获取：
**https://modrinth.com/modpack/the-horrors-in-the-fog**

## 无担保声明
本程序不提供任何担保，详情请参阅 GPLv3 许可证。

## 原项目信息
- **原项目名称**: The Horrors in the Fog
- **原作者**: theernyclan
- **源代码链接**: https://modrinth.com/modpack/the-horrors-in-the-fog
- **原许可证**: GNU General Public License v3.0

完整的许可证条款请参阅 [LICENSE](LICENSE) 文件。